import csv
import numpy as np
import math
import statistics
import smtplib
from sklearn import svm
from sklearn.externals import joblib
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier

def readTrainData(file):
	with open(file, 'r') as f:
		reader = csv.reader(f)
		in_list = list(reader)	
	working_list = np.array(in_list)[1:].astype(int)
	labels = working_list[:,0]
	data = working_list[0:,1:]
	return data, labels

def testSample(labels, data, test_size):
	data_train, data_test, labels_train, labels_test = train_test_split(data, labels, test_size = test_size, random_state = 0)

	return data_train, data_test, labels_train, labels_test

def splitData(file):
	data, labels = readTrainData(file)
	count = int(math.floor(len(data)/10))
	data_test = []
	labels_test = []
	for i in range(0, count):
		data_test.append(data[i])
		labels_test.append(labels[i])
	data_train = []
	labels_train = []
	for i in range(count+1, len(data)):
		data_train.append(data[i])
		labels_train.append(labels[i])
	return data_test, labels_test, data_train, labels_train

def fitKNN(file):
	data_test, labels_test, data_train, labels_train = splitData(file)
	neigh = KNeighborsClassifier(n_neighbors=4, weights = 'distance', algorithm = 'brute')
	neigh.fit(data_train, labels_train)
	prediction_nn = neigh.predict(data_test)
	probs_nn = neigh.predict_proba(data_test)

	return prediction_nn, probs_nn

def fitRF(file):
	data_test, labels_test, data_train, labels_train = splitData(file)
	clf = RandomForestClassifier(n_estimators = 100)
	clf.fit(data_train, labels_train)
	prediction_rf = clf.predict(data_test)
	probs_rf = clf.predict_proba(data_test)

	return prediction_rf, probs_rf

def saveLinear(data, labels):
	for i in range(100):
		data_train, data_test, labels_train, labels_test = testSample(labels, data, 0.3)
		clf = svm.LinearSVC()
		clf.fit(data_train, labels_train)
		filename1 = 'trained_linear_%d.pkl'%(i,)
		filename2 = 'test_data_%d.pkl'%(i,)
		filename3 = 'test_labels_%d.pkl'%(i,)
		joblib.dump(clf, filename1)
		#joblib.dump(data_test, filename2)
		#joblib.dump(labels_test, filename3)

def loadTrainedSets():
	trained = []
	data = []
	labels = []
	for i in range(100):
		filename1 = 'trained_linear_%d.pkl'%(i,)
		clf = joblib.load(filename1)
		trained.append(clf)
	return trained

def main():
	# loading data and fitting a knn and random forest model
	data_test, labels_test, data_train, labels_train = splitData('train.csv')
	prediction_nn, probs_nn = fitKNN('train.csv')
	prediction_rf, probs_rf = fitRF('train.csv')
	# loading my trained svm sets
	trained = loadTrainedSets()
	prediction_pool = []
	for i in range(len(trained)):
		clf = trained[i]
		prediction_svm = clf.predict(data_test)
		prediction_pool.append(prediction_svm)
	# need the transpose for looping
	prediction_pool = np.array(prediction_pool).T.tolist()
	final_prediction = []
	for i in range(len(prediction_nn)):
		max_prob_nn = max(probs_nn[i])
		max_prob_rf = max(probs_rf[i])
		index_max_prob_nn = list(probs_nn[i]).index(max_prob_nn)
		index_max_prob_rf = list(probs_rf[i]).index(max_prob_rf)
		try:
			max_prob_svm = statistics.mode(prediction_pool[i])
		except statistics.StatisticsError:
			max_prob_svm = prediction_nn[i]
			a = prediction_pool[i]
			print(a)
			d = {x:a.count(x) for x in a}
			print(d, labels_test[i])
			print(d.keys(), d.values())


		possible_preds = [index_max_prob_nn, index_max_prob_rf, max_prob_svm]
		#try:
		#	final_prediction.append(statistics.mode(possible_preds))
		#except statistics.StatisticsError:
		#	final_prediction.append(index_max_prob_nn)
		if max_prob_nn > .5:
			final_prediction.append(prediction_nn[i])
		elif max_prob_rf > .75:
			final_prediction.append(prediction_rf[i])
		else:
			final_prediction.append(max_prob_svm)
	check = []
	count = 0
	for i in range(len(final_prediction)):
		if final_prediction[i] == labels_test[i]:
			check.append(1)
		else:
			check.append(0)
			count = count + 1
			print('Predicted: ', final_prediction[i], 'Actual: ', labels_test[i])
			print('---------------------')
	result = np.mean(check)
	print(result)
	print('Number wrong: ', count)	
main()

'''
  Number Weight
  0     10
  1     8
  2     3
  3     2
  4     6
  5     5
  6     9
  7     4
  8     7
  9     1
'''