import csv
import numpy as np
import math
import statistics
import smtplib
from sklearn.ensemble import RandomForestClassifier

def readTrainData(file):
	with open(file, 'r') as f:
		reader = csv.reader(f)
		in_list = list(reader)	
	working_list = np.array(in_list)[1:].astype(int)
	labels = working_list[:,0]
	data = working_list[0:,1:]
	return data, labels

def testSample(labels, data, test_size):
	data_train, data_test, labels_train, labels_test = train_test_split(data, labels, test_size = test_size, random_state = 0)

	return data_train, data_test, labels_train, labels_test

def splitData(file):
	data, labels = readTrainData(file)
	count = int(math.floor(len(data)/10))
	data_test = []
	labels_test = []
	for i in range(0, count):
		data_test.append(data[i])
		labels_test.append(labels[i])
	data_train = []
	labels_train = []
	for i in range(count+1, len(data)):
		data_train.append(data[i])
		labels_train.append(labels[i])
	return data_test, labels_test, data_train, labels_train

def sendEmail(msg):
	server = smtplib.SMTP('smtp.gmail.com', 587)
	server.starttls()
	server.login("WBBPredictions@gmail.com", "Team6969")
	server.sendmail("WBBPredictions@gmail.com", "terrisbecker@gmail.com", msg)
	server.quit()

def main():
	data_test, labels_test, data_train, labels_train = splitData('train.csv')
	clf = RandomForestClassifier(n_estimators = 100, random_state = 0)
	clf.fit(data_train, labels_train)
	prediction = clf.predict(data_test)
	probs = clf.predict_proba(data_test)
	check = []
	for i in range(len(prediction)):
		if prediction[i] == labels_test[i]:
			check.append(1)
		else:
			check.append(0)
	result = np.mean(check)
	print(result)
	print(probs)
main()