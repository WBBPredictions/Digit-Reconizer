import csv
import numpy as np
import math
import statistics
from sklearn.externals import joblib
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

def readTrainData(file):
	with open(file, 'r') as f:
		reader = csv.reader(f)
		in_list = list(reader)	
	working_list = np.array(in_list)[1:].astype(int)
	labels = working_list[:,0]
	data = working_list[0:,1:]
	return data, labels

def testSample(labels, data, test_size):
	data_train, data_test, labels_train, labels_test = train_test_split(data, labels, test_size = test_size, random_state = 0)

	return data_train, data_test, labels_train, labels_test

def main():
	print('Reading data...')
	data, labels = readTrainData('train.csv')
	data_train, data_test, labels_train, labels_test = testSample(labels, data, .3)
	print('Creating decision tree...')
	clf = DecisionTreeClassifier(random_state=0)
	clf.fit(data_train, labels_train)
	print('Making predictions...')
	prediction_list = clf.predict(data_test)
	compare = []
	for i in range(len(prediction_list)):
		if prediction_list[i] == labels_test[i]:
			compare.append(1)
		else:
			compare.append(0)
	accuracy = np.mean(compare)
	print('Done...')
	print(accuracy)
main()